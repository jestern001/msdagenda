package com.webage.service;

import java.util.Collection;

import com.webage.domain.Customer;

public interface CustomerService {

	Collection<Customer> findAll();

	Customer findById(long id);

	Customer findByName(String name);

}