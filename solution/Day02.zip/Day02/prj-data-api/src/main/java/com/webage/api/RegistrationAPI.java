package com.webage.api;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.webage.domain.Registration;
import com.webage.service.RegistrationService;

@RestController
@RequestMapping("/registrations")
public class RegistrationAPI {
    @Autowired
    RegistrationService service;
    
	@GetMapping
	public Collection<Registration> getAll() {
		return service.findAll();
	}

	@GetMapping("/{registrationId}")
	public Registration getRegistrationById(@PathVariable("registrationId") long id) {
		Registration response = service.findById(id);
		return response;
	}

}
