package com.webage.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.webage.domain.Customer;
import com.webage.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository repo;
	
	@Override
	public Collection<Customer> findAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Customer findById(long id) {
		// TODO Auto-generated method stub
		return repo.findById(id);
	}

	@Override
	public Customer findByName(String name) {
		// TODO Auto-generated method stub
		return repo.findByName(name);
	}

}
