package com.webage.api;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.webage.domain.Customer;
import com.webage.service.CustomerService;

@RestController
@RequestMapping("/customers")
public class CustomerAPI {
	@Autowired
	private CustomerService service;

	public CustomerAPI() {

	}

	@GetMapping
	public Collection<Customer> getAll() {
		return service.findAll();
	}

	@GetMapping("/{id}")
	public Customer getCustomerById(@PathVariable long id) {
		Customer response = service.findById(id);
		return response;
	}
	
	@GetMapping("/byName/{name}")
	public Customer getCustomerByName(@PathVariable String name) {
		Customer response = service.findByName(name);
		return response;
	}

}
