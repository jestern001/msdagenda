package com.webage.repository;



import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;

import org.springframework.stereotype.Repository;

import com.webage.domain.Registration;

@Repository
public class RegistrationRepository {
	ArrayList<Registration> list = new ArrayList<Registration>();
	
	public RegistrationRepository() throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Registration r1 = new Registration(1, "1", "1", dateFormat.parse("2019-01-20"), "You are invited");
		Registration r2 = new Registration(2, "2", "1", dateFormat.parse("2020-05-20"), "Looking forward to the meeting!");
		Registration r3 = new Registration(3, "1", "2", dateFormat.parse("2020-12-31"), "New Year party!");
		list.add(r1);
		list.add(r2);
		list.add(r3);
	}
	
	public Collection<Registration> findAll() {
		return list;
	}
	
	public Registration findById(long id) {
		Registration response = null;
		for(Registration c : list) {
			if(c.getId() == id) {
				response = c;
			}
		}
		
		return response;
	}
	
}
