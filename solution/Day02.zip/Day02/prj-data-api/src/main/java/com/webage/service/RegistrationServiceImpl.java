package com.webage.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.webage.domain.Registration;
import com.webage.repository.RegistrationRepository;

@Service
public class RegistrationServiceImpl implements RegistrationService {
	@Autowired 
	private RegistrationRepository repo;
	
	@Override
	public Collection<Registration> findAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Registration findById(long id) {
		// TODO Auto-generated method stub
		return repo.findById(id);
	}

}
