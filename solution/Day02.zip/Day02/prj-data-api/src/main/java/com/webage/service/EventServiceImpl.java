package com.webage.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.webage.domain.Event;
import com.webage.repository.EventRepository;

@Service
public class EventServiceImpl implements EventService {
    
	@Autowired
	private EventRepository repo;
	
	@Override
	public Collection<Event> findAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Event findById(long id) {
		// TODO Auto-generated method stub
		return repo.findById(id);
	}

}
