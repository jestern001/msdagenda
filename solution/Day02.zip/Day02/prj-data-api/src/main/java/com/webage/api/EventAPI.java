package com.webage.api;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.webage.domain.Event;
import com.webage.service.EventService;

@RestController
@RequestMapping("/events")
public class EventAPI {
	@Autowired
	private EventService service;

	public EventAPI() {

	}

	@GetMapping
	public Collection<Event> getAll() {
		return service.findAll();
	}

	@GetMapping("/{eventId}")
	public Event getEventById(@PathVariable("eventId") long id) {
		Event response = service.findById(id);

		return response;
	}

}
