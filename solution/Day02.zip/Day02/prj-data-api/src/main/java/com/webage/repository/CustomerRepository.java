package com.webage.repository;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.stereotype.Repository;

import com.webage.domain.Customer;

@Repository
public class CustomerRepository  {
	ArrayList<Customer> list = new ArrayList<Customer>();
	
	public CustomerRepository() {
		Customer c1 = new Customer(1, "Steve", "pass", "steve@abc.com");
		Customer c2 = new Customer(2, "Bob", "pass", "bob@abc.com");
		Customer c3 = new Customer(3, "Cindy", "pass", "cindy@abc.com");
		list.add(c1);
		list.add(c2);
		list.add(c3);
	}
	
	public Collection<Customer> findAll() {
		return list;
	}
	
	public Customer findById(long id) {
		Customer response = null;
		for(Customer c : list) {
			if(c.getId() == id) {
				response = c;
			}
		}
		
		return response;
	}
	
	public Customer findByName(String name) {
		Customer response = null;
		for(Customer c : list) {
			if(c.getName().equals(name)) {
				response = c;
			}
		}
		
		return response;
	}
}
