package com.webage.service;

import java.util.Collection;

import com.webage.domain.Registration;

public interface RegistrationService {
	Collection<Registration> findAll();
	Registration findById(long id);
}
