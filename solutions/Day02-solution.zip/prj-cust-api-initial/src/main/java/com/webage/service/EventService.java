package com.webage.service;

import java.util.Collection;

import com.webage.domain.Event;

public interface EventService {
	Collection<Event> findAll();
	Event findById(long id);
}
