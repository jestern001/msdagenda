package com.webage.repository;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.stereotype.Repository;

import com.webage.domain.Event;

@Repository
public class EventRepository {
	ArrayList<Event> list = new ArrayList<Event>();
	
	public EventRepository() {
		Event e1 = new Event(1, "E1", "Weekly Meeting", "Weekly meeting #1");
		Event e2 = new Event(2, "E2", "Sales Meeting", "Sales meeting FY2020");
		list.add(e1);
		list.add(e2);
	}
	
	public Collection<Event> findAll() {
		return list;
	}

	public Event findById(long id) {
		Event response = null;
		for(Event c : list) {
			if(c.getId() == id) {
				response = c;
			}
		}
		
		return response;

	}

}
